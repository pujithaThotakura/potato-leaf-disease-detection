# Techsaksham_AI_Potato_Leaf_Disease_Prediction
This application uses Convolutional Neural Network (CNN) to determine if a potato plant leaf is healthy or it suffers from early blight or late blight disease. A web application is developed for the model and it is deployed using Streamlit.
